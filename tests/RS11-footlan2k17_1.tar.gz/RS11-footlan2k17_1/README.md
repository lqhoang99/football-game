# RS11-footlan2k17
Turn-based soccer game inspired by "Pocket Soccer".
