extern const int WINDOW_WIDTH;
extern const int WINDOW_HEIGHT;
extern const int GOAL_WIDTH;
extern const int GOAL_HEIGHT;

extern const char* TITLE;
extern const double UPDATE_TIME;
